# Cloudflare Tunnel widget for pfSense 2.7.x

A native pfSense dashboard widget for a `cloudflared` tunnel running directly on the firewall.

The widget uses only local sources:

- `cloudflared` metrics and `/diag/tunnel` on `127.0.0.1:20241-20245`
- PF state counters for Cloudflare Tunnel traffic on destination port 7844

It does not need or store a Cloudflare API token.

## Displayed information

- Healthy, degraded, or down status
- Active and expected HA connections
- QUIC/UDP or HTTP/2/TCP transport
- Cloudflare edge locations
- Smoothed QUIC RTT range
- Total proxied requests and origin errors
- Cumulative QUIC packet events by reason
- Live sent and received rates, sampled every five seconds
- Rolling five-minute traffic graph while the dashboard is open
- Cumulative PF bytes sent and received for the current states

## Install

Upload the release archive to pfSense using **Diagnostics > Command Prompt > Upload File**, or copy it to `/tmp` with SCP.

From console option **8 — Shell**:

```sh
cd /tmp
tar -xzf cloudflare-tunnel-widget-pfsense-1.0.3.tar.gz
cd cloudflare-tunnel-widget-pfsense-1.0.3
sh install.sh
```

Then open **Status > Dashboard**, expand **Available Widgets**, and add **Cloudflare Tunnel**.

## Upgrade recovery

pfSense upgrades may replace custom files under `/usr/local/www`. The installer retains a clean copy under `/conf`, which pfSense normally preserves.

Restore the widget after an upgrade with:

```sh
sh /conf/cloudflare-tunnel-widget/install.sh
```

## Uninstall

```sh
sh /conf/cloudflare-tunnel-widget/uninstall.sh
```

The retained source and timestamped backups under `/conf/cloudflare-tunnel-widget` are intentionally preserved.

## Compatibility

Built for pfSense 2.7.2 and the metric names emitted by `cloudflared 2026.2.0`.
